document.getElementById("customerLink").addEventListener("click", function() {
    alert("You clicked on Customer!");
});

document.getElementById("staffLink").addEventListener("click", function() {
    alert("You clicked on Staff!");
});
